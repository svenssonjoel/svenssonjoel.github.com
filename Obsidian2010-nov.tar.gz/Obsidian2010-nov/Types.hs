
{-
  Types.hs, odds and ends (hardly in use at the moment i think) 
  
  Joel Svensson

  Todo: 
    
-}

module Types where

type Name = String
