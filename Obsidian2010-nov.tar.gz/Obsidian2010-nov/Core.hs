{-# OPTIONS -fglasgow-exts        #-}

{- 
   Core.hs, Main datastructures
   Joel Svensson
-}

module Core where 

import Flatten 

import Arr 
import Exp

import Text.Show.Functions

--------------------------------------------------------------------------------

{-
data a :-> b 
    = Pure (a -> b)
    | First (a :-> b) 
    | Sync (a -> Arr FData) (Arr FData :-> b) 
    | PSync (IndexE -> IntE) (a -> Arr FData) (Arr FData :-> b) 
      deriving Show
-}

data a :-> b where 
    Pure  :: (a -> b) -> (a :-> b) 
    Sync  :: (a -> Arr FData) -> (Arr FData :-> b) -> (a :-> b)

--------------------------------------------------------------------------------

runS :: a :-> b -> a -> b
runS (Pure f) a = f a  
runS (Sync f g) a = let a' = f a in runS g a'





--------------------------------------------------------------------------------


