
{- Joel Svensson 2012 -} 

module Obsidian.Globs where


import Data.Word

---------------------------------------------------------------------------
-- Aliases

type Name = String



type NumThreads = Word32