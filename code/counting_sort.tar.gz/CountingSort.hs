{-# LANGUAGE FlexibleContexts #-}
module CountingSort where

import Data.Ix
import Data.Array.Unboxed

import Data.Array.ST hiding (unsafeThaw)
import Data.Array.Unsafe
import Control.Monad.ST

import Test.QuickCheck
import Data.List (sort,nub)

----------------------------------------------------------------------
-- Full counting sort for arbitrary elements

countingSort :: (a -> Int) -> (Int,Int) -> Array Int a -> Array Int a
countingSort key range input = construct inp    $
                               scanlArray (+) 0 $
                               histogram range  $
                               fmap snd inp
  where inp = fmap (\a -> (a,key a)) input

histogram :: (Int,Int) -> Array Int Int -> Array Int Int
histogram range = accumArray (\i _ -> i+1) 0 range . elems . fmap dup

construct :: Array Int (a,Int) -> Array Int Int -> Array Int a
construct inp pos = array (0,lastArr pos - 1) $
                    runST (do arr <- thaw pos
                              loop arr (elems inp))
  where loop :: STArray s Int Int -> [(a,Int)] -> ST s [(Int,a)]
        loop arr []         = return []
        loop arr ((x,k):xs) = do i  <- readArray arr k
                                 writeArray arr k (i+1)
                                 is <- loop arr xs
                                 return ((i,x):is)

----------------------------------------------------------------------
-- A version of counting sort which removes duplicates
-- It can be implemented in a purely functional way

countingSortUnique :: (a -> Int) -> (Int,Int) -> [a] -> Array Int a
countingSortUnique key range input =
    reconstruct inp $
    scanlArray (+) 0 $
    histo' range $
    map snd inp
  where inp = map (\a -> (a,key a)) input

reconstruct inp pos
    = array (0,lastArr pos - 1) [ (pos!key,a) | (a,key) <- inp ]

histo' :: (Int,Int) -> [Int] -> Array Int Int
histo' range = accumArray (\_ _ -> 1) 0 range . fmap dup

----------------------------------------------------------------------
-- Sorting integers
-- This version doesn't have to look at the input array during the reconstruct
-- step, it uses the indices of the position array to figure out what elements
-- the input array contained.

countingSortInt :: (Int,Int) -> Array Int Int -> Array Int Int
countingSortInt range input =
  recons $
  scanlArray (+) 0 $
  histogram range input

recons :: Array Int Int -> Array Int Int
recons arr = array (0,arr!l-1)
               [ (a,i)
               | (i,e) <- init (assocs arr)
               , a <- [ e .. arr!(i+1) - 1] ]
  where (_,l) = bounds arr

countingSortU :: (Int,Int) -> Array Int Int -> Array Int Int
countingSortU range input =
  recons $
  scanlArray (+) 0 $
  histo range input

histo :: (Int,Int) -> Array Int Int -> Array Int Int
histo range = accumArray (\_ _ -> 1) 0 range . elems . fmap dup

-- Helper functions

scanlArray :: (IArray arr b, IArray arr a, Ix i, Num i) =>
              (a -> b -> a) -> a -> arr i b -> arr i a
scanlArray f e arr = listArray (l,h+1) $ scanl f e $ elems arr
       where (l,h) = bounds arr

lastArr :: (IArray arr a, Ix i) => arr i a -> a
lastArr arr = arr ! i
  where (_,i) = bounds arr

dup a = (a,a)

----------------------------------------------------------------------
-- Testing

composeRange :: Ord a => (a,a) -> (a,a) -> (a,a)
composeRange (l1,u1) (l2,u2) = (min l1 l2,max u1 u2)

computeRange :: Ord a => [a] -> (a,a)
computeRange = foldr1 composeRange . map dup

prop_countingSort
  = forAll intList $ \input ->
      let r = computeRange input in
        elems (countingSort id r (listArray (1,length input) input)) == sort input

prop_countingSortUnique
  = forAll intList $ \input ->
      let r = computeRange input in
        elems (countingSortUnique id r input) == sort (nub input)

prop_countingSortInt
  = forAll intList $ \input ->
      let r = computeRange input in
        elems (countingSortInt r (listArray (1,length input) input)) == sort input

prop_countingSortIU
  = forAll intList $ \input ->
      let r = computeRange input in
        elems (countingSortU r (listArray (1,length input) input)) == nub (sort input)

-- We use a different generator for integers to make sure that we don't generate
-- too big a range.
intList :: Gen [Int]
intList = listOf1 (sized ints)
  where ints i = choose (0,if i > 1000 then round (sqrt (fromIntegral i)) else i)
