
{-# LANGUAGE ScopedTypeVariables,
             FlexibleContexts #-} 


{-
   depending on where you keep Obsidian
   ghci CSObsidian.hs -i../../Obsidian
-}
 
module CSObsidian where


import qualified Obsidian.CodeGen.CUDA as CUDA

import Obsidian.Program

import Obsidian.Exp
import Obsidian.Types
import Obsidian.Array
import Obsidian.Library
import Obsidian.Force
import Obsidian.CodeGen.InOut
import Obsidian.Atomic

import Data.Word
import Data.Int
import Data.Bits

import qualified Data.Vector.Storable as V

import Control.Monad.State

import Prelude hiding (zipWith,sum,replicate, last )
import qualified Prelude as P 

---------------------------------------------------------------------------
-- Util 
---------------------------------------------------------------------------
quickPrint :: ToProgram a b => (a -> b) -> Ips a b -> IO ()
quickPrint prg input =
  putStrLn $ CUDA.genKernel "kernel" prg input 
 
---------------------------------------------------------------------------
--
-- Countingsort start
--
---------------------------------------------------------------------------

-- gather: output is as long as the array of indices.
--   this is same as permutePush above (gather may be better name)
-- gather should likely be a GlobPull a -> GlobPull a ! 
gatherGlobal :: GlobPull (Exp Word32)
                -> GlobPull a
                -> GlobPush a
gatherGlobal indices elems    =
  GlobPush $
  \wf ->
    forAllT $ \gix -> let inix = indices ! gix
                          e    = elems ! inix 
                      in wf e gix 

scatterGlobal :: GlobPull (Exp Word32) -- where to scatter
                 -> GlobPull a -- the elements to scatter
                 -> GlobPush a 
scatterGlobal indices elems =
  GlobPush $
    \wf -> forAllT $ \gix ->
    let scix = indices ! gix
        e    = elems   ! gix
    in  wf e scix 

--distribute :: a -> GlobPull a
--distribute e = GlobPull $ \gix -> e           

histogram :: GlobPull (Exp Int32)
             -> GlobPush (Exp Word32)
             -- a type cast is needed!
histogram elems = scatterGlobal (fmap int32ToWord32 elems) (replicateG 1)


reconstruct :: GlobPull (Exp Int32)
               -> GlobPull (Exp Word32)
               -> GlobPush (Exp Int32)
reconstruct inp pos = scatterGlobal (ixMap f pos)  inp  
  where
    f gix = fmap int32ToWord32 inp ! gix
  

reconstruct' :: GlobPull (Exp Word32)
                -> GlobPush (Exp Int32)
reconstruct' (GlobPull ixf) = GlobPush f
  where f k = do forAllT $ \gix ->
                   let startIx = ixf gix in
                   Cond ((ixf (gix + 1) - startIx) ==* 1) $
                      k (word32ToInt32 gix) startIx

getReconstruct' = quickPrint (forceG . reconstruct') undefinedGlobal
getReconstruct = quickPrint (\arr arr1 -> forceG (reconstruct arr arr1) ) (undefinedGlobal :-> undefinedGlobal)

-- This function is supposed to compute the histogram for the input vector.
-- Three things I'm not sure about:
    -- 1. The looping that I do seems to be wrong. How do I do it correctly?
    -- The intention is to loop over the whole input array.
    -- 2. Are arrays initialized to zero? If we want to use this for counting
    -- sort then the `global` array needs to be zero everywhere from the start.
    -- 3. The type is really weird. It uses both GlobPull and GlobPull2. I just
    -- used whatever was most convenient for each task.
fullHistogram :: GlobPull (Exp Int32)
                 -> Final (GProgram (GlobPull (Exp Word32)))
fullHistogram (GlobPull ixf) = Final $
                 do global <- Output $ Pointer (typeOf (undefined :: Exp Word32))
                    forAllT $ \gix ->
                      do AtomicOp global (int32ToWord32 (ixf gix))  AtomicInc
                         return ()
                    return (GlobPull (\i -> index global i))

getFullHistogram = quickPrint (fullHistogram) undefinedGlobal

      

-- Possible answers:
-- #1: I think I adapted the code to answer this.
--     This is how it might work, at least in this experimental branch
-- #2: Normally not initialized to zero. When allocating a global array
--     it should be followed by a "memset". but this is outside of what we
--     can do from inside Obsidian right now.
-- #3: I changed this to only use GlobPull. (GlobPull2 is removed in this branch)

-- Are the types supposed to be this way ? 
fullReconstruct :: GlobPull (Exp Word32)
                -> GlobPush (Exp Int32)
fullReconstruct (GlobPull ixf) = GlobPush f
  where f k = do forAllT $ \gix ->
                   let startIx = ixf gix in
                   SeqFor (ixf (gix + 1) - startIx) $ \ix ->
                      k (word32ToInt32 gix) (ix + startIx)

getFullReconstr = quickPrint (forceG . fullReconstruct) undefinedGlobal

---------------------------------------------------------------------------
-- Scan
---------------------------------------------------------------------------
sklansky :: Int -> (EWord32 -> EWord32 -> EWord32)
            -> Pull EWord32 -> BProgram (Pull EWord32)
sklansky 0 op arr = return arr
sklansky n op arr =
  do 
    let arr1 = binSplit (n-1) (fan op) arr
    arr2 <- force arr1
    sklansky (n-1) op arr2

sklanskyMax :: Int -> (EWord32 -> EWord32 -> EWord32)
     -> Pull EWord32 -> Program Block (Pull EWord32, Pull EWord32)
sklanskyMax n op arr = do
  res <- sklansky n op arr
  return (res,singleton (last res))


-- Need to add codegen support form
-- functions returning GPrograms !
-- Codegeneration now also may need to support
-- certain cases of sequences of ForAllBlock..
-- I Think the important distinction there is if
-- its used as a case of forAllT or not. Maybe this
-- indicates that there should be a separate ForAllT
-- constructor in the Program type. 
sklanskyG :: Int -> GlobPull EWord32
             -> GProgram (GlobPush EWord32, GlobPush EWord32)
sklanskyG logbsize input =
  toGProgram (mapDist (sklanskyMax logbsize (+)) (2^logbsize) input)

sklanskyGP logbsize input =
  do
    (r1,r2) <- sklanskyG logbsize input
    forceGP r1
    forceGP r2
    return (r1, r2)
    
getSklanskyGP = quickPrint (sklanskyGP 8) (undefinedGlobal :: GlobPull (EWord32))
getSklanskyGP16 = quickPrint (sklanskyGP 4) (undefinedGlobal :: GlobPull (EWord32))
getSklanskyGP32 = quickPrint (sklanskyGP 5) (undefinedGlobal :: GlobPull (EWord32))
getSklanskyGP64 = quickPrint (sklanskyGP 6) (undefinedGlobal :: GlobPull (EWord32))
getSklanskyGP128 = quickPrint (sklanskyGP 7) (undefinedGlobal :: GlobPull (EWord32))
getSklanskyGP512 = quickPrint (sklanskyGP 9) (undefinedGlobal :: GlobPull (EWord32))

fan op arr =  a1 `conc`  fmap (op (last a1)) a2 
    where 
      (a1,a2) = halve arr
      



distribute :: EWord32 -> GlobPull EWord32
              -> GlobPull EWord32 -> GlobPull EWord32
distribute bs maxs inputs = zipWithG (+) maxs' inputs 
  where 
    maxs' = repeat bs maxs
    repeat n = ixMap (\ix -> ix `div` n)
    
--     repeat n (GlobPull ixf) = GlobPull $ \ix -> ixf (ix `div` n) 


getDist = quickPrint distr
                     ((undefined :: Exp Word32) :-> 
                      (undefinedGlobal :: GlobPull (Exp Word32)) :->
                      (undefinedGlobal :: GlobPull (Exp Word32)) )
          where distr s i1 i2 = forceG $ pushG $ distribute s i1 i2 
---------------------------------------------------------------------------
-- Print Kernels
---------------------------------------------------------------------------

getHist = quickPrint (forceG .  histogram) undefinedGlobal

getRecon = quickPrint reconstruct'  
             ((undefinedGlobal :: GlobPull (Exp Int32)) :->
              (undefinedGlobal :: GlobPull (Exp Word32)))
           where
             reconstruct' i1 i2 = forceG (reconstruct i1 i2)




---------------------------------------------------------------------------
-- Hacking
---------------------------------------------------------------------------
forAllT' :: GlobPull (Program Thread ()) -> Program Grid ()
forAllT' (GlobPull gixf) = forAllT gixf

forAllLocal :: Pull (Program Thread ()) -> Program Block ()
forAllLocal (Pull n ixf) = ForAll (Just n) ixf 
