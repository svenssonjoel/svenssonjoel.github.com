#!/bin/bash


for i in 1 2 4 8 
do 
    ./time${i}M > obs${i}M.dat 
    echo Bench $i done.
done 