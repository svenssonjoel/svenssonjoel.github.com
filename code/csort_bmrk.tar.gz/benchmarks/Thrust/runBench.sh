#!/bin/bash


for i in 0 1 2 3 4 5
do 
    ./thrust $i > thrust${i}.dat 
    echo Bench $i done.
done 