#!/bin/bash


for i in 4 8 16 32 
do 
    ./time${i}M > obs${i}M.dat 
    echo Bench $i done.
done 