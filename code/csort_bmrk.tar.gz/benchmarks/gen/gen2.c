

#include <stdio.h> 
#include <stdlib.h> 
#include <stdint.h> 
#include <time.h>

// Build 
// gcc -std=c99 -o gen2 gen2.c


// Example:
// ./gen2 $((1024*1024*16)) 256 hej.dat

int main(int argc, const char *argv[]) { 

  if (argc != 4) 
    printf("usage: %s n_elts max outfile", argv[0]); 


  FILE *fp = fopen(argv[3],"w"); 
  
  int nval = atoi(argv[1]);
  int max  = atoi(argv[2]);
  
  printf("Generating %d random uint32_t in the interval 0 to %d\n",nval,max-1);
  
  uint32_t *values = (uint32_t*)malloc(sizeof(uint32_t)*nval);
 
  srand(time(NULL));
 
  printf("Generating \n");
  for (int i = 0; i < nval; ++i) { 
    values[i] = rand() % max;

  }
  printf("Done\n");
 
  fwrite(values,sizeof(uint32_t),nval,fp);

  fclose(fp);

} 
