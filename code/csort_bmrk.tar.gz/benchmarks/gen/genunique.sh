#!/bin/bash


for i in 1 2 4 8 16 
do 
    ./gen $((1024*1024*$i)) data${i}MUnique.dat
done
