
#include <stdio.h> 
#include <stdlib.h> 
#include <stdint.h> 
#include <time.h> 

// Build 
// gcc -std=c99 -o gen gen.c

// Example:
// ./gen $((1024*1024*16)) hej.dat

// Generates N elements in the interval 0 - N 
// with no duplications! (It does this in a very ad-hoc way) 
// Execution time can be quite long. 

int main(int argc, const char *argv[]) { 

  if (argc != 3) 
    printf("usage: %s n_elts outfile", argv[0]); 


  FILE *fp = fopen(argv[2],"w"); 
  
  int nval = atoi(argv[1]);
  
  printf("Generating %d random uint32_t in the interval 0 to %d\n",nval,nval-1);
  
  uint32_t *values;
  int32_t  *values0 = (int32_t*)malloc(sizeof(int32_t)*nval);
 


  for (int i = 0; i < nval; ++i) {
    values0[i] = -1; // rand () % (N -1); // (N - 1 - i);
  }


  srand(time(NULL));
  // shuffle (might run for a very long time) 
  printf("Generating \n");
  for (int i = 0; i < nval; ++i) { 
    
    int sc = 0;   
    uint32_t n;
  back:
    if (sc == 5) {
      fprintf(stdout,"X");fflush(stdout);
      n = 0; 
    }
    else n = rand()%nval;
    while (values0[n] != -1 && n < nval)     
      n = n+1; 
    if (n < nval) 
      values0[n] = i;
    else {
      sc ++;
      goto back;
    }

    if (i % 256 == 0) fprintf(stdout,".");fflush(stdout);
    if (i % 2048 == 0) fprintf(stdout,"\n%d\n", i);
  }
  printf("Done\n");
  
  values = (uint32_t*)values0;

  fwrite(values,sizeof(uint32_t),nval,fp);

  fclose(fp);

} 
