#!/bin/bash

#1 2 4 8 16 
for i in 32
do 
    for j in 256 512 1024 2048 4096 8192 16384 32768 65536 131072 262144 524288 1048576
    do 
	./gen2 $((1024*1024*$i)) ${j} data${i}M${j}.dat
    done
    
    if [ $i -gt 1 ] 
	  then ./gen2 $((1024*1024*$i)) 2097152 data${i}M2097152.dat
    fi 	  

    if [ $i -gt 2 ] 
	  then ./gen2 $((1024*1024*$i)) 4194304 data${i}M4194304.dat
    fi 	  

    if [ $i -gt 4 ] 
	  then ./gen2 $((1024*1024*$i)) 8388608 data${i}M8388608.dat
    fi 	  
    
    if [ $i -gt 8 ] 
	  then ./gen2 $((1024*1024*$i)) 16777216 data${i}M16777216.dat
    fi 	  

    if [ $i -gt 16 ] 
	  then ./gen2 $((1024*1024*$i)) 33554432 data${i}M33554432.dat
    fi 	  
	  
    
done
