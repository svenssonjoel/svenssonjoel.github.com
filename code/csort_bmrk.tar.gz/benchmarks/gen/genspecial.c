
#include <stdio.h> 
#include <stdlib.h> 
#include <stdint.h> 
#include <time.h> 

// Build 
// gcc -std=c99 -o genspecial genspecial.c

// Example:
// ./genspecial $((1024*1024*16)) hej.dat

// Generates a sorted array N elements long containing elemenst 0 - (N-1)
// Generates an array that has a bad distribution for GPUs
 

int main(int argc, const char *argv[]) { 

  if (argc != 3) 
    printf("usage: %s n_elts outfile", argv[0]); 

  char outsorted[256]; 
  char outstrange[256];


  
  int nval = atoi(argv[1]);
  
  sprintf(outsorted,"%ssort",argv[2]);
  sprintf(outstrange,"%swarp",argv[2]);

  FILE *fp1 = fopen(outsorted,"w"); 
  FILE *fp2 = fopen(outstrange,"w"); 
  
  int32_t  *values = (int32_t*)malloc(sizeof(int32_t)*nval);
  int32_t  *values1 = (int32_t*)malloc(sizeof(int32_t)*nval);

  printf("Generating \n");
  for (int i = 0; i < nval; ++i) { 
    values[i] = i;
    values1[i] = i / 32;
  }

  fwrite(values,sizeof(int32_t),nval,fp1);
  fwrite(values1,sizeof(int32_t),nval,fp2);
  

 
  fclose(fp1);
  fclose(fp2);
 

} 
