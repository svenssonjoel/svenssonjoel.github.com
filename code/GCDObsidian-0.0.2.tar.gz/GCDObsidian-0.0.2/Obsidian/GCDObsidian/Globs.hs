module Obsidian.GCDObsidian.Globs where
 

------------------------------------------------------------------------------
-- Aliases

type Name = String
