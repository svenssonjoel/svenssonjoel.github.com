
module Types where

type Name = String
